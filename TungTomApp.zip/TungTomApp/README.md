# TungTom APK

App Android (WebView) chạy userscript **TungTom v1.11.0** cho pokesurvivor.com / pokesurvivor.doofcraft.com.
Menu điều khiển nằm trong app (nút 🍤 kéo được ở góc màn hình) thay cho bảng trong trang.

## Build APK
**Cách 1 – GitHub Actions (không cần máy tính):** tạo repo GitHub, upload toàn bộ thư mục này
(giữ nguyên `.github/`), vào tab *Actions* → *Build APK* → tải artifact `TungTom-apk`.

**Cách 2 – Android Studio:** Open thư mục này → Build → Build APK(s) → `app/build/outputs/apk/debug/`.

## Menu 🍤 (5 tab, nút to, tab nằm cạnh trái khi xoay ngang / đáy khi xoay dọc)
- 🎮 **Bot**: Chơi / Dừng / Tạm dừng / Tiếp tục, số ván (− +), overlay debug, chế độ ván doofcraft.
- 📺 **Màn nhỏ**: bản thu nhỏ của trang. **Chạm hoặc kéo trên khung = chạm/kéo trong game**. Chỉnh tốc độ vẽ lại
  (2 / 5 / 10 / 20 khung/giây), kiểu vẽ (thu nhỏ / ít màu), nội dung (toàn trang / chỉ canvas), và mở **toàn màn hình**
  (có thanh nhỏ: Đóng, Menu, tốc độ vẽ).
- ⚡ **Giảm lag**: chọn nhanh 4 mức; "Tuỳ chỉnh chi tiết" bấm mở ra mới thấy.
- 👤 **Tài khoản**: nhập tài khoản + mật khẩu, bấm "Lưu & đăng nhập ngay" để app tự điền vào form của trang rồi bấm
  đăng nhập. Có thể bật "Tự đăng nhập khi mở game" (tối đa 1 lần / 60 giây). Mật khẩu mã hoá bằng Android Keystore,
  mỗi trang (pokesurvivor.com / doofcraft) lưu một tài khoản riêng. Không dùng được nếu game chỉ có nút đăng nhập Google.
- ⚙ **Cài đặt**: đổi trang, tự xoay ngang, toàn màn hình, giữ sáng, ẩn bảng trong trang, xoá dữ liệu, thoát.
Mã vẽ khung thu nhỏ, chạm và đăng nhập nằm trong `assets/bridge.js`.

## Cập nhật script
Chép đè `app/src/main/assets/TungTom_user.js` rồi build lại.

## Lưu ý
- Userscript được tiêm ở document-start (giống Via/Tampermonkey), nên hook game hoạt động như bản gốc.
- Nút "Xuất data.js" (tải file) của bảng F6 không dùng được trong WebView; phím F6–F9 cũng không có trên điện thoại.
- Gốc: damhieu2808/PokeSurvivorTool (MIT).
