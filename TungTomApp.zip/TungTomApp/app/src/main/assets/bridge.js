// Cầu nối app <-> trang.
//  1) Ẩn/hiện bảng điều khiển gốc của userscript (menu đã chuyển sang app).
//  2) Bản thu nhỏ của trang: snap(w) trả ảnh (data URL) cho menu; touch() chuyển chạm trên khung thành chạm trên trang.
//  3) login()/autoLogin(): tự điền tài khoản + mật khẩu vào form đăng nhập của trang rồi bấm nút đăng nhập.
// window.__TT_HIDE và window.__TT_MINI do MainActivity đặt ngay trước file này.
(function () {
  if (window.__TT) return;

  // ---------- 1) ẩn bảng điều khiển gốc ----------
  var st = null;
  function apply() {
    var root = document.head || document.documentElement;
    if (!root) return;
    if (window.__TT_HIDE && !st) {
      st = document.createElement('style');
      st.textContent = '[data-psbot-dock]{display:none!important}';
      root.appendChild(st);
    } else if (!window.__TT_HIDE && st) {
      st.remove();
      st = null;
    }
  }

  // ---------- 2) bản thu nhỏ của trang (hiện trong menu của app) ----------
  // Lấy hàm vẽ gốc NGAY bây giờ (bridge chạy trước userscript): lớp lite/bot của userscript sẽ bọc
  // CanvasRenderingContext2D.prototype.drawImage sau đó, ta không muốn bản thu nhỏ bị chúng lọc hay ghi nhận.
  var nativeDraw = CanvasRenderingContext2D.prototype.drawImage;
  var DEF = { style: 'full', mode: 'page' };
  var cfg = {};
  var cv = null, g = null, items = [], itemsAt = -1e9;
  var PW = 420;   // chiều rộng ảnh xem trước (px)

  function mergeCfg(o) {
    for (var k in DEF) cfg[k] = (o && o[k] !== undefined) ? o[k] : (cfg[k] !== undefined ? cfg[k] : DEF[k]);
  }

  var SKIP = /^(SCRIPT|STYLE|LINK|META|HEAD|TITLE|NOSCRIPT|BR|TEMPLATE|OPTION)$/;

  // Quét DOM thành danh sách hình đơn giản theo thứ tự tài liệu. Chậm hơn nên chỉ làm vài lần/giây.
  function scan() {
    var out = [], n = 0, VW = innerWidth, VH = innerHeight;
    var tw = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    var el;
    while ((el = tw.nextNode()) && n < 700) {
      if (SKIP.test(el.tagName) || el.closest('[data-psbot-ui],[data-tt-mini]')) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2 || r.right < 0 || r.bottom < 0 || r.left > VW || r.top > VH) continue;
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') continue;
      var tag = el.tagName, it = null;
      if (tag === 'CANVAS') {
        out.push({ t: 'cv', el: el, r: r }); n++; continue;
      }
      var bg = cs.backgroundColor, hasBg = bg && bg !== 'transparent' && !/rgba\(.*,\s*0\)$/.test(bg);
      var bw = parseFloat(cs.borderTopWidth) || 0, hasBd = bw > 0 && cs.borderTopStyle !== 'none';
      var rad = parseFloat(cs.borderTopLeftRadius) || 0;
      if (tag === 'IMG' || tag === 'VIDEO' || tag === 'SVG' || tag === 'svg') {
        out.push({ t: 'media', r: r, rad: rad }); n++;
      } else if (hasBg || hasBd || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'BUTTON') {
        out.push({ t: 'box', r: r, rad: rad, bg: hasBg ? bg : null, bd: hasBd ? cs.borderTopColor : (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ? '#889' : null) });
        n++;
      }
      // chữ: node text trực tiếp của phần tử này -> vẽ thành các vạch
      var txt = '';
      for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) txt += c.nodeValue;
      txt = txt.replace(/\s+/g, ' ').trim();
      if (!txt && (tag === 'INPUT' || tag === 'TEXTAREA')) txt = (el.value || el.placeholder || '').trim();
      if (txt) {
        var fs = parseFloat(cs.fontSize) || 12, lh = parseFloat(cs.lineHeight) || fs * 1.25;
        var lines = Math.max(1, Math.min(6, Math.round(r.height / lh)));
        var wpx = Math.min(r.width, txt.length * fs * 0.52 / lines + fs);
        out.push({ t: 'txt', x: r.left + (tag === 'BUTTON' || cs.textAlign === 'center' ? (r.width - wpx) / 2 : 0), y: r.top, w: wpx, lines: lines, lh: lh, fs: fs, col: cs.color });
        n++;
      }
    }
    return out;
  }

  function rr(ctx, x, y, w, h, rad) {
    if (rad > 1 && ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x, y, w, h, Math.min(rad, w / 2, h / 2)); return true; }
    return false;
  }

  function gameCanvas() {
    return document.getElementById('game') || document.querySelector('canvas.ps-canvas') ||
      document.querySelector('canvas:not([data-psbot-ui])');
  }

  function drawCanvas(c, r, k) {
    try { nativeDraw.call(g, c, r.left * k, r.top * k, r.width * k, r.height * k); } catch (e) {}
  }

  function posterize() {
    try {
      var im = g.getImageData(0, 0, cv.width, cv.height), d = im.data;
      for (var i = 0; i < d.length; i += 4) {
        d[i] = (d[i] + 32) >> 6 << 6; d[i + 1] = (d[i + 1] + 32) >> 6 << 6; d[i + 2] = (d[i + 2] + 32) >> 6 << 6;
      }
      g.putImageData(im, 0, 0);
    } catch (e) {}
  }

  function render() {
    if (!cv) { cv = document.createElement('canvas'); cv.setAttribute('data-psbot-ui', ''); g = cv.getContext('2d'); }
    var W = PW, H = Math.max(30, Math.round(PW * innerHeight / Math.max(1, innerWidth)));
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    var k = W / Math.max(1, innerWidth);
    g.globalAlpha = 1;
    g.fillStyle = (getComputedStyle(document.body).backgroundColor || '#000');
    if (g.fillStyle === 'rgba(0, 0, 0, 0)') g.fillStyle = '#0b0f14';
    g.fillRect(0, 0, W, H);
    g.imageSmoothingEnabled = cfg.style !== 'simple';

    if (cfg.mode === 'canvas') {
      var gc = gameCanvas();
      if (gc) {
        var r0 = gc.getBoundingClientRect();
        drawCanvas(gc, r0, k);
      }
    } else {
      var now = performance.now();
      if (now - itemsAt > 450) { items = scan(); itemsAt = now; }
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it.t === 'cv') { drawCanvas(it.el, it.el.getBoundingClientRect(), k); continue; }
        if (it.t === 'txt') {
          g.fillStyle = it.col; g.globalAlpha = 0.85;
          var bh = Math.max(1, it.fs * 0.55 * k);
          for (var l = 0; l < it.lines; l++) {
            var ww = l === it.lines - 1 && it.lines > 1 ? it.w * 0.6 : it.w;
            g.fillRect(it.x * k, (it.y + l * it.lh + (it.lh - it.fs * 0.55) / 2) * k, Math.max(1, ww * k), bh);
          }
          g.globalAlpha = 1; continue;
        }
        var x = it.r.left * k, y = it.r.top * k, w = it.r.width * k, h = it.r.height * k;
        if (it.t === 'media') {
          g.fillStyle = '#5a6577'; g.strokeStyle = '#9aa7ba';
          if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); }
          g.fill(); g.stroke(); continue;
        }
        if (it.bg) { g.fillStyle = it.bg; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.fill(); }
        if (it.bd) { g.strokeStyle = it.bd; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.stroke(); }
      }
    }
    if (cfg.style === 'simple') posterize();
  }

  // snap(w): ảnh thu nhỏ của trang, rộng w px. Kiểu "đơn giản" dùng PNG (ít màu), còn lại JPEG cho nhẹ.
  function snap(w) {
    if (!document.body) return null;
    PW = Math.max(120, Math.min(1280, w | 0 || 420));
    render();
    return cv.toDataURL(cfg.style === 'simple' ? 'image/png' : 'image/jpeg', 0.6);
  }

  // ---------- 3) chạm/kéo trên bản thu nhỏ = chạm/kéo trên trang thật ----------
  // Tọa độ chuẩn hoá 0..1. Mô phỏng một cú chạm thật: pointer + touch (+ mouse/click nếu là chạm nhanh, không kéo).
  var tch = null, tid = 0;
  function ptrEv(type, x, y, id, down) {
    return new PointerEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y, pointerId: 100 + id, pointerType: 'touch', isPrimary: true,
      width: 1, height: 1, pressure: down ? 0.5 : 0, button: type === 'pointermove' ? -1 : 0, buttons: down ? 1 : 0 });
  }
  function touchEv(type, x, y, id, target) {
    var t = new Touch({ identifier: id, target: target, clientX: x, clientY: y, pageX: x + scrollX, pageY: y + scrollY, screenX: x, screenY: y });
    var end = type === 'touchend' || type === 'touchcancel';
    return new TouchEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      touches: end ? [] : [t], targetTouches: end ? [] : [t], changedTouches: [t] });
  }
  function mouseEv(type, x, y, down) {
    return new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: down ? 1 : 0 });
  }
  function send(el, mk) { try { el.dispatchEvent(mk()); } catch (e) {} }
  function touch(phase, nx, ny) {
    var x = Math.round(Math.max(0, Math.min(1, nx)) * (innerWidth - 1));
    var y = Math.round(Math.max(0, Math.min(1, ny)) * (innerHeight - 1));
    if (phase === 'down') {
      var el = document.elementFromPoint(x, y) || document.body;
      tch = { el: el, x: x, y: y, moved: false, id: ++tid };
      send(el, function () { return ptrEv('pointerdown', x, y, tch.id, true); });
      send(el, function () { return touchEv('touchstart', x, y, tch.id, el); });
      return;
    }
    if (!tch) return;
    var s = tch, t = s.el;
    if (phase === 'move') {
      if (Math.abs(x - s.x) + Math.abs(y - s.y) > 12) s.moved = true;
      send(t, function () { return ptrEv('pointermove', x, y, s.id, true); });
      send(t, function () { return touchEv('touchmove', x, y, s.id, t); });
      return;
    }
    var cancel = phase === 'cancel';
    send(t, function () { return ptrEv(cancel ? 'pointercancel' : 'pointerup', x, y, s.id, false); });
    send(t, function () { return touchEv(cancel ? 'touchcancel' : 'touchend', x, y, s.id, t); });
    if (!cancel && !s.moved) {
      send(t, function () { return mouseEv('mousemove', x, y, false); });
      send(t, function () { return mouseEv('mousedown', x, y, true); });
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) { try { t.focus(); } catch (e) {} }
      send(t, function () { return mouseEv('mouseup', x, y, false); });
      send(t, function () { return mouseEv('click', x, y, false); });
    }
    tch = null;
  }

  // ---------- 4) tự điền tài khoản + mật khẩu và đăng nhập ----------
  // Tìm ô mật khẩu đang hiện, ô tài khoản đứng ngay trước nó, điền (kiểu React/Vue cũng nhận), rồi bấm nút đăng nhập.
  var loginStatus = '', autoDone = false;
  function vis(el) {
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
  }
  function setVal(el, v) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, 'value');
    try { el.focus(); } catch (e) {}
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var TXT = /^(text|email|tel|search|url|)$/i;
  // So khớp chữ không dấu (tiếng Việt có thể mã hoá theo nhiều kiểu): "Đăng nhập" -> "dang nhap"
  function plain(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[đĐ]/g, 'd').toLowerCase(); }
  var USER_RE = /user|email|mail|login|account|tai.?khoan|ten/;
  function findFields() {
    var all = [].slice.call(document.querySelectorAll('input')).filter(function (i) { return vis(i) && !i.disabled && !i.readOnly; });
    var pw = null, k;
    for (k = 0; k < all.length; k++) if (all[k].type === 'password') { pw = all[k]; break; }
    if (!pw) return null;
    var before = null;
    for (k = all.indexOf(pw) - 1; k >= 0; k--) if (TXT.test(all[k].type || '')) { before = all[k]; break; }
    var named = all.filter(function (i) {
      return i !== pw && TXT.test(i.type || '') && (!pw.form || i.form === pw.form) &&
        USER_RE.test(plain((i.name || '') + ' ' + (i.id || '') + ' ' + (i.autocomplete || '') + ' ' + (i.placeholder || '')));
    })[0];
    return { pw: pw, user: named || before };
  }
  var GO_RE = /log\s*in|sign\s*in|dang\s*nhap|submit|continue|tiep\s*tuc|vao|enter|play/;
  var BAD_RE = /google|facebook|apple|discord|github|register|sign\s*up|dang\s*ky|guest|khach|forgot|quen/;
  function btnText(b) { return plain((b.innerText || b.value || b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim()); }
  function submit(pw) {
    var node = pw.form || pw.parentElement, hops = 0, pick = null;
    while (node && !pick && hops++ < 6) {
      var bs = [].slice.call(node.querySelectorAll('button,input[type=submit],input[type=button],[role=button]'))
        .filter(function (b) { return vis(b) && !b.disabled && !BAD_RE.test(btnText(b)); });
      pick = bs.filter(function (b) { return b.type === 'submit'; })[0] || bs.filter(function (b) { return GO_RE.test(btnText(b)); })[0] || null;
      node = node.parentElement;
    }
    if (pick) { pick.click(); return; }
    if (pw.form) { try { pw.form.requestSubmit(); } catch (e) { pw.form.submit(); } return; }
    ['keydown', 'keypress', 'keyup'].forEach(function (t) {
      pw.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    });
  }
  function clickOpener() {
    var c = [].slice.call(document.querySelectorAll('button,a,[role=button]')).filter(function (b) {
      return vis(b) && /^(log\s*in|sign\s*in|dang\s*nhap)$/.test(btnText(b));
    })[0];
    if (c) c.click();
  }
  function attempt(u, p, timeout, allowOpen) {
    var t0 = Date.now(), opened = false;
    loginStatus = 'Đang tìm ô đăng nhập…';
    (function step() {
      var f = null;
      try { f = findFields(); } catch (e) {}
      if (f) {
        try {
          if (f.user) setVal(f.user, u);
          setVal(f.pw, p);
          loginStatus = f.user ? 'Đã điền tài khoản + mật khẩu và gửi đăng nhập' : 'Đã điền mật khẩu (không thấy ô tài khoản) và gửi đăng nhập';
          setTimeout(function () {
            try { submit(f.pw); } catch (e) { loginStatus = 'Đã điền nhưng không bấm được nút đăng nhập'; }
          }, 250);
        } catch (e) { loginStatus = 'Lỗi khi điền form: ' + e.message; }
        return;
      }
      var el = Date.now() - t0;
      if (allowOpen && !opened && el > 800) { opened = true; try { clickOpener(); } catch (e) {} }
      if (el > timeout) { loginStatus = 'Không thấy ô mật khẩu trên trang (nếu game chỉ có đăng nhập bằng Google thì tính năng này không dùng được)'; return; }
      setTimeout(step, 300);
    })();
  }

  mergeCfg(window.__TT_MINI);

  window.__TT = {
    hide: function (b) { window.__TT_HIDE = !!b; apply(); },
    mini: {
      set: function (o) { mergeCfg(o); itemsAt = -1e9; },
      get: function () { return JSON.parse(JSON.stringify(cfg)); },
      snap: snap,
      touch: touch
    },
    login: function (u, p) { attempt(String(u), String(p), 8000, true); return 'started'; },
    autoLogin: function (u, p) { if (autoDone) return 'skip'; autoDone = true; attempt(String(u), String(p), 20000, false); return 'started'; },
    get loginStatus() { return loginStatus; }
  };
  apply();
  document.addEventListener('DOMContentLoaded', apply);
})();
