package com.tungtom.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.security.KeyStore;
import java.util.Locale;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends AppCompatActivity {
    private static final String HOME_DEFAULT = "https://pokesurvivor.com/";
    private static final String HOME_DOOF = "https://pokesurvivor.doofcraft.com/";

    private WebView web;
    private FrameLayout root;
    private TextView fab;
    private SharedPreferences prefs;
    private String userScript = "";
    private String bridgeScript = "";
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "RequiresFeature"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tt", MODE_PRIVATE);

        userScript = readAsset("TungTom_user.js");
        bridgeScript = readAsset("bridge.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        applyWindowFlags();
        applyOrientation();
        setupWebView();
        setupFab();

        String url = prefs.getString("url", HOME_DEFAULT);
        if (getIntent() != null && getIntent().getData() != null) url = getIntent().getData().toString();
        web.loadUrl(url);
    }

    // ---------- WebView + tiêm userscript ----------
    @SuppressLint({"SetJavaScriptEnabled", "RequiresFeature"})
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        WebView.setWebContentsDebuggingEnabled(true);

        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (docStartSupported) registerDocStart();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                // Máy không hỗ trợ document-start script: tiêm muộn hơn một chút (hook.js có thể trượt)
                if (!docStartSupported && isGameUrl(url)) v.evaluateJavascript(fullScript(), null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (!isGameUrl(url)) return;
                prefs.edit().putString("url", url).apply();
                if (prefs.getBoolean("autoLogin", false)) {
                    String[] c = loadCred(siteKey(url));
                    long now = System.currentTimeMillis();
                    // tối đa 1 lần / 60 giây để không lặp khi đăng nhập sai
                    if (c != null && now - prefs.getLong("autoLoginAt", 0) > 60000) {
                        prefs.edit().putLong("autoLoginAt", now).apply();
                        runLogin(c[0], c[1], true);
                    }
                }
            }
        });
    }

    private boolean isGameUrl(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost();
        return h.equals("pokesurvivor.com") || h.equals("www.pokesurvivor.com") || h.equals("pokesurvivor.doofcraft.com");
    }

    private String fullScript() {
        return "window.__TT_HIDE=" + prefs.getBoolean("hidePanel", true) + ";\nwindow.__TT_MINI=" + miniCfg().toString()
                + ";\n" + bridgeScript + "\n" + userScript;
    }

    @SuppressLint("RequiresFeature")
    private void registerDocStart() {
        if (scriptHandler != null) scriptHandler.remove();
        Set<String> origins = new HashSet<>();
        origins.add("https://pokesurvivor.com");
        origins.add("https://www.pokesurvivor.com");
        origins.add("https://pokesurvivor.doofcraft.com");
        scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, fullScript(), origins);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    // ---------- cửa sổ: toàn màn hình, giữ sáng ----------
    private void applyWindowFlags() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (prefs.getBoolean("fullscreen", true)) {
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            c.show(androidx.core.view.WindowInsetsCompat.Type.systemBars());
        }
        if (prefs.getBoolean("keepAwake", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // Tự xoay ngang: khoá ở hướng ngang nhưng vẫn lật giữa 2 chiều ngang theo cảm biến
    private void applyOrientation() {
        setRequestedOrientation(prefs.getBoolean("landscape", true)
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyWindowFlags();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else openMenu();   // Back ở trang đầu: mở menu thay vì thoát nhầm
    }

    @Override
    protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); }
        super.onDestroy();
    }

    // ---------- nút nổi 🍤 (kéo được, chạm = mở menu) ----------
    @SuppressLint("ClickableViewAccessibility")
    private void setupFab() {
        fab = new TextView(this);
        fab.setText("🍤");
        fab.setTextSize(20);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xAA141A22);
        bg.setStroke(dp(1), 0xFF3A4553);
        fab.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(44), dp(44));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = dp(8);
        lp.rightMargin = dp(8);
        root.addView(fab, lp);

        final float[] down = new float[4];
        final boolean[] moved = new boolean[1];
        fab.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX(); down[1] = e.getRawY();
                    down[2] = v.getX();    down[3] = v.getY();
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - down[0], dy = e.getRawY() - down[1];
                    if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved[0] = true;
                    if (moved[0]) {
                        v.setX(Math.max(0, Math.min(root.getWidth() - v.getWidth(), down[2] + dx)));
                        v.setY(Math.max(0, Math.min(root.getHeight() - v.getHeight(), down[3] + dy)));
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) openMenu();
                    return true;
                default:
                    return true;
            }
        });
    }

    // ---------- tài khoản: lưu mã hoá bằng khoá Android Keystore ----------
    private SecretKey credKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias("tt_cred")) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder("tt_cred", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey("tt_cred", null);
    }

    private String enc(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, credKey());
        byte[] ct = c.doFinal(plain.getBytes("UTF-8"));
        return Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }

    private String dec(String s) throws Exception {
        String[] p = s.split(":");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, credKey(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), "UTF-8");
    }

    /** "doof" cho pokesurvivor.doofcraft.com, còn lại "main": mỗi trang lưu một tài khoản riêng. */
    private String siteKey(String url) {
        String h = "";
        try { h = Uri.parse(url == null ? "" : url).getHost(); } catch (Exception ignored) {}
        return h != null && h.contains("doofcraft") ? "doof" : "main";
    }

    private String[] loadCred(String site) {
        String s = prefs.getString("cred_" + site, null);
        if (s == null) return null;
        try {
            JSONObject o = new JSONObject(dec(s));
            return new String[]{o.optString("u"), o.optString("p")};
        } catch (Exception e) { return null; }
    }

    private boolean saveCred(String site, String u, String p) {
        try {
            JSONObject o = new JSONObject();
            o.put("u", u);
            o.put("p", p);
            prefs.edit().putString("cred_" + site, enc(o.toString())).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    private void runLogin(String u, String p, boolean auto) {
        js("window.__TT&&__TT." + (auto ? "autoLogin" : "login") + "&&__TT." + (auto ? "autoLogin" : "login")
                + "(" + JSONObject.quote(u) + "," + JSONObject.quote(p) + ")");
    }

    private String unq(String v) {
        if (v == null || v.equals("null")) return "";
        try {
            Object o = new JSONTokener(v).nextValue();
            return o instanceof String ? (String) o : String.valueOf(o);
        } catch (Exception e) { return v; }
    }

    private void toast(String t) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show();
    }

    // ---------- cấu hình màn hình nhỏ (lưu trong prefs, nạp lại mỗi lần tải trang) ----------
    private JSONObject miniCfg() {
        try { return new JSONObject(prefs.getString("mini", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private void setMini(String key, Object value) {
        try {
            JSONObject o = miniCfg();
            o.put(key, value);
            prefs.edit().putString("mini", o.toString()).apply();
        } catch (Exception ignored) { return; }
        js("window.__TT&&__TT.mini&&__TT.mini.set(" + miniCfg().toString() + ")");
        if (docStartSupported) registerDocStart();   // trang tải sau dùng cấu hình mới
    }

    // Trong lúc khung đang hiện: xin trang một ảnh thu nhỏ (data URL) rồi đặt vào ImageView.
    // Vòng lặp chờ ảnh trước xong rồi mới xin ảnh sau, cách nhau theo "tốc độ vẽ" (khung/giây) đã chọn.
    private void startPreview(final Dialog owner, final ImageView pv, final int width) {
        final int gen = ++previewGen;
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (gen != previewGen || !owner.isShowing()) return;
            final long t0 = SystemClock.uptimeMillis();
            web.evaluateJavascript("(function(){try{return window.__TT&&__TT.mini?__TT.mini.snap(" + width + "):null}catch(e){return null}})()", value -> {
                try {
                    String str = unq(value);
                    int comma = str.indexOf(',');
                    if (comma > 0) {
                        byte[] raw = Base64.decode(str.substring(comma + 1), Base64.DEFAULT);
                        Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                        if (bm != null) {
                            BitmapDrawable bd = new BitmapDrawable(getResources(), bm);
                            bd.setFilterBitmap(!"simple".equals(miniCfg().optString("style", "full")));
                            pv.setImageDrawable(bd);
                        }
                    }
                } catch (Exception ignored) {}
                if (gen != previewGen || !owner.isShowing()) return;
                long every = 1000L / Math.max(1, miniCfg().optInt("fps", 5));
                ui.postDelayed(tick[0], Math.max(0L, every - (SystemClock.uptimeMillis() - t0)));
            });
        };
        tick[0].run();
    }

    // Đổi điểm chạm trên ImageView (FIT_CENTER) thành toạ độ 0..1 của ảnh
    private float[] mapTouch(ImageView v, MotionEvent e) {
        Drawable dr = v.getDrawable();
        if (dr == null) return null;
        float iw = dr.getIntrinsicWidth(), ih = dr.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0 || v.getWidth() <= 0 || v.getHeight() <= 0) return null;
        float sc = Math.min(v.getWidth() / iw, v.getHeight() / ih);
        float dw = iw * sc, dh = ih * sc;
        float ox = (v.getWidth() - dw) / 2f, oy = (v.getHeight() - dh) / 2f;
        float nx = (e.getX() - ox) / dw, ny = (e.getY() - oy) / dh;
        return new float[]{Math.max(0f, Math.min(1f, nx)), Math.max(0f, Math.min(1f, ny))};
    }

    private void touchCall(String phase, float[] m) {
        js(String.format(Locale.US, "window.__TT&&__TT.mini&&__TT.mini.touch('%s',%.4f,%.4f)", phase, m[0], m[1]));
    }

    // Chạm / kéo trên khung = chạm / kéo trên trang thật
    @SuppressLint("ClickableViewAccessibility")
    private void attachTouch(final ImageView pv) {
        final long[] last = new long[1];
        pv.setOnTouchListener((v, e) -> {
            float[] m = mapTouch(pv, e);
            if (m == null) return true;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                    last[0] = 0;
                    touchCall("down", m);
                    break;
                case MotionEvent.ACTION_MOVE:
                    long now = SystemClock.uptimeMillis();
                    if (now - last[0] >= 30) { last[0] = now; touchCall("move", m); }
                    break;
                case MotionEvent.ACTION_UP:
                    touchCall("up", m);
                    break;
                case MotionEvent.ACTION_CANCEL:
                    touchCall("cancel", m);
                    break;
                default:
                    break;
            }
            return true;
        });
    }

    // ---------- màn hình nhỏ toàn màn hình ----------
    private static final int[] MINI_FPS = {2, 5, 10, 20};

    @SuppressLint("ClickableViewAccessibility")
    private void openMiniFull() {
        if (menuDlg != null) menuDlg.dismiss();
        final Dialog fd = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout fl = new FrameLayout(this);
        fl.setBackgroundColor(Color.BLACK);
        final ImageView pv = new ImageView(this);
        pv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        fl.addView(pv, new FrameLayout.LayoutParams(-1, -1));
        attachTouch(pv);

        // thanh nhỏ nổi góc trên trái: Đóng | Menu | tốc độ vẽ
        LinearLayout bar = row();
        GradientDrawable bbg = new GradientDrawable();
        bbg.setColor(0xB0141A22);
        bbg.setCornerRadius(dp(10));
        bar.setBackground(bbg);
        bar.setPadding(dp(4), dp(2), dp(4), dp(2));
        bar.addView(btn("✕ Đóng", 0xFF4D2429, 0xFFFF9A9A, v -> fd.dismiss()));
        bar.addView(btn("☰ Menu", v -> { fd.dismiss(); openMenu(); }));
        int fi = 1;
        for (int i = 0; i < MINI_FPS.length; i++) if (MINI_FPS[i] == miniCfg().optInt("fps", 5)) fi = i;
        String[] fl2 = new String[MINI_FPS.length];
        for (int i = 0; i < MINI_FPS.length; i++) fl2[i] = String.valueOf(MINI_FPS[i]);
        bar.addView(segment(fl2, fi, i -> setMini("fps", MINI_FPS[i])), new LinearLayout.LayoutParams(0, -2, 2));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(440), -2, Gravity.TOP | Gravity.START);
        blp.setMargins(dp(8), dp(8), dp(8), dp(8));
        fl.addView(bar, blp);

        fd.setContentView(fl);
        fd.setOnDismissListener(x -> previewGen++);
        Window w = fd.getWindow();
        if (w != null) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
        fd.show();
        startPreview(fd, pv, 720);
    }

    // ---------- menu native: tab ở cạnh trái (ngang) hoặc đáy (dọc), nội dung cuộn, nút to ----------
    private Dialog menuDlg;
    private LinearLayout menuBody;
    private TextView menuStatus;
    private Button[] tabBtns;
    private int curTab = 0;
    private boolean liteAdv = false;
    private int previewGen = 0;

    private static final String[] TAB_ICON = {"🎮", "📺", "⚡", "👤", "⚙"};
    private static final String[] TAB_NAME = {"Bot", "Màn nhỏ", "Giảm lag", "Tài khoản", "Cài đặt"};

    private void openMenu() {
        if (menuDlg != null && menuDlg.isShowing()) return;
        showMenu();
    }

    private void showMenu() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        menuDlg = d;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final boolean land = dm.widthPixels > dm.heightPixels;

        LinearLayout rootCol = new LinearLayout(this);
        rootCol.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF141A22);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF2E3845);
        rootCol.setBackground(bg);

        // đầu menu: tên + trạng thái bot + nút đóng
        LinearLayout head = row();
        head.setPadding(dp(14), dp(6), dp(6), dp(2));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.addView(title("🍤 TungTom"));
        menuStatus = muted("Đang đọc trạng thái…");
        ht.addView(menuStatus);
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = btn("✕", v -> d.dismiss());
        close.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(44)));
        head.addView(close);
        rootCol.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // nội dung cuộn
        menuBody = new LinearLayout(this);
        menuBody.setOrientation(LinearLayout.VERTICAL);
        menuBody.setPadding(dp(12), dp(2), dp(12), dp(12));
        ScrollView sv = new ScrollView(this);
        sv.addView(menuBody);

        // thanh tab
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(land ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(4), dp(2), dp(4), dp(4));
        tabBtns = new Button[TAB_NAME.length];
        for (int i = 0; i < TAB_NAME.length; i++) {
            final int idx = i;
            Button tb = btn(TAB_ICON[i] + "\n" + TAB_NAME[i], v -> selectTab(idx));
            tb.setTextSize(11);
            tb.setMinimumHeight(dp(46));
            LinearLayout.LayoutParams tp = land ? new LinearLayout.LayoutParams(-1, 0, 1) : new LinearLayout.LayoutParams(0, -2, 1);
            tp.setMargins(dp(2), dp(2), dp(2), dp(2));
            tb.setLayoutParams(tp);
            tabs.addView(tb);
            tabBtns[i] = tb;
        }
        if (land) {
            LinearLayout mid = new LinearLayout(this);
            mid.setOrientation(LinearLayout.HORIZONTAL);
            mid.addView(tabs, new LinearLayout.LayoutParams(dp(84), -1));
            mid.addView(sv, new LinearLayout.LayoutParams(0, -1, 1));
            rootCol.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1));
        } else {
            rootCol.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
            rootCol.addView(tabs, new LinearLayout.LayoutParams(-1, -2));
        }

        d.setContentView(rootCol);
        d.setOnDismissListener(x -> { previewGen++; menuDlg = null; });
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(dm.widthPixels - dp(16), dp(land ? 660 : 440)), (int) (dm.heightPixels * (land ? 0.94f : 0.92f)));
            w.setGravity(Gravity.CENTER);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
        selectTab(curTab);
    }

    private void fetchState(final Consumer<JSONObject> cb) {
        String q = "(function(){try{var o={host:location.hostname};"
                + "if(window.PSLite)o.lite=PSLite.get();"
                + "if(window.PSBot){var s=PSBot.state;o.bot={on:!!s.on,done:s.done,target:s.target,debug:!!s.debug};}"
                + "try{o.run=JSON.parse(localStorage.getItem('psbot.dcRun')||'{}');}catch(e){o.run={};}"
                + "return o;}catch(e){return {};}})()";
        web.evaluateJavascript(q, value -> {
            JSONObject st;
            try { st = new JSONObject(value == null || value.equals("null") ? "{}" : value); }
            catch (Exception e) { st = new JSONObject(); }
            cb.accept(st);
        });
    }

    private void selectTab(final int i) {
        if (menuDlg == null) return;
        curTab = i;
        previewGen++;
        for (int k = 0; k < tabBtns.length; k++) paint(tabBtns[k], k == i);
        menuBody.removeAllViews();
        switch (i) {
            case 0: fetchState(st -> { if (menuDlg != null && curTab == i) buildBotTab(st); }); break;
            case 1: buildScreenTab(); break;
            case 2: fetchState(st -> { if (menuDlg != null && curTab == i) buildLiteTab(st); }); break;
            case 3: buildAccountTab(); break;
            default: buildAppTab(); break;
        }
    }

    private void updateStatus(JSONObject st) {
        JSONObject bot = st.optJSONObject("bot");
        if (bot == null) { menuStatus.setText("Bot: chưa tải (đợi game vào xong rồi mở lại menu)"); return; }
        menuStatus.setText("Bot: " + (bot.optBoolean("on") ? "ĐANG CHẠY" : "dừng")
                + " · ván " + (bot.optInt("done") + 1) + (bot.optInt("target") > 0 ? "/" + bot.optInt("target") : ""));
    }

    // ----- tab 1: Bot -----
    private void buildBotTab(JSONObject st) {
        updateStatus(st);
        final Dialog d = menuDlg;
        JSONObject bot = st.optJSONObject("bot");
        JSONObject run = st.optJSONObject("run");
        String host = st.optString("host", "");
        LinearLayout col = menuBody;

        // số ván: − [5] +
        LinearLayout rr = row();
        rr.addView(muted("Số ván (0 = vô hạn)"), new LinearLayout.LayoutParams(0, -2, 1));
        final EditText runs = new EditText(this);
        runs.setInputType(InputType.TYPE_CLASS_NUMBER);
        runs.setText(String.valueOf(prefs.getInt("runs", 5)));
        runs.setTextColor(Color.WHITE);
        runs.setTextSize(16);
        runs.setGravity(Gravity.CENTER);
        runs.setSingleLine(true);
        runs.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        Button minus = btn("−", v -> runs.setText(String.valueOf(Math.max(0, parseRuns(runs) - 1))));
        Button plus = btn("+", v -> runs.setText(String.valueOf(parseRuns(runs) + 1)));
        minus.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(44)));
        plus.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(44)));
        rr.addView(minus);
        rr.addView(runs, new LinearLayout.LayoutParams(dp(64), -2));
        rr.addView(plus);
        col.addView(rr);

        LinearLayout r1 = row();
        r1.addView(bigBtn("▶ Chơi", 0xFF1F4A33, 0xFF7EE2A8, v -> {
            int n = parseRuns(runs);
            prefs.edit().putInt("runs", n).apply();
            botCall("PSBot.play(" + n + ")");
            d.dismiss();
        }));
        r1.addView(bigBtn("■ Dừng", 0xFF4D2429, 0xFFFF9A9A, v -> { botCall("PSBot.stop()"); d.dismiss(); }));
        col.addView(r1);
        LinearLayout r2 = row();
        r2.addView(bigBtn("⏸ Tạm dừng", 0xFF1D2530, 0xFFE6EBF2, v -> { botCall("PSBot.pause()"); d.dismiss(); }));
        r2.addView(bigBtn("⏯ Tiếp tục", 0xFF1D2530, 0xFFE6EBF2, v -> { botCall("PSBot.resume()"); d.dismiss(); }));
        col.addView(r2);

        col.addView(sw("Hiện overlay debug", bot != null && bot.optBoolean("debug"),
                (b, on) -> botCall("PSBot.state.debug=" + on)));

        if (host.contains("doofcraft")) {
            col.addView(section("Chế độ ván (doofcraft)"));
            col.addView(muted("Chế độ"));
            col.addView(segment(new String[]{"Game", "Normal", "Waves"},
                    idx(new String[]{"game", "normal", "waves"}, run == null ? "game" : run.optString("mode", "game")),
                    i -> setRun("mode", new String[]{"game", "normal", "waves"}[i])));
            col.addView(muted("Độ khó"));
            col.addView(segment(new String[]{"Game", "Easy", "Medium", "Hard"},
                    idx(new String[]{"game", "easy", "medium", "hard"}, run == null ? "game" : run.optString("difficulty", "game")),
                    i -> setRun("difficulty", new String[]{"game", "easy", "medium", "hard"}[i])));
            col.addView(muted("HYPER"));
            col.addView(segment(new String[]{"Game", "Tắt", "Bật"},
                    idx(new String[]{"game", "off", "on"}, run == null ? "game" : run.optString("hyper", "game")),
                    i -> setRun("hyper", new String[]{"game", "off", "on"}[i])));
        }
    }

    private int parseRuns(EditText e) {
        try { return Math.max(0, Integer.parseInt(e.getText().toString().trim())); }
        catch (Exception ex) { return 5; }
    }

    // ----- tab 2: Màn hình nhỏ (xem trước + chạm + tốc độ vẽ + toàn màn hình) -----
    private void buildScreenTab() {
        LinearLayout col = menuBody;
        final ImageView pv = new ImageView(this);
        pv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pv.setBackgroundColor(Color.BLACK);
        col.addView(pv, new LinearLayout.LayoutParams(-1, dp(200)));
        attachTouch(pv);
        col.addView(muted("Chạm hoặc kéo trên khung = chạm vào game"));
        col.addView(bigBtn1("⛶ Mở toàn màn hình", 0xFF1F3A5C, 0xFF9CC8FF, v -> openMiniFull()));

        col.addView(section("Tốc độ vẽ lại (khung/giây)"));
        int fi = 1;
        String[] fl = new String[MINI_FPS.length];
        for (int i = 0; i < MINI_FPS.length; i++) {
            fl[i] = String.valueOf(MINI_FPS[i]);
            if (MINI_FPS[i] == miniCfg().optInt("fps", 5)) fi = i;
        }
        col.addView(segment(fl, fi, i -> setMini("fps", MINI_FPS[i])));
        col.addView(muted("Thấp = đỡ tốn pin và đỡ lag game; cao = mượt hơn"));

        col.addView(section("Kiểu hiển thị"));
        col.addView(segment(new String[]{"Thu nhỏ", "Đơn giản (ít màu)"},
                idx(new String[]{"full", "simple"}, miniCfg().optString("style", "full")),
                i -> setMini("style", new String[]{"full", "simple"}[i])));
        col.addView(segment(new String[]{"Toàn trang", "Chỉ canvas game"},
                idx(new String[]{"page", "canvas"}, miniCfg().optString("mode", "page")),
                i -> setMini("mode", new String[]{"page", "canvas"}[i])));

        startPreview(menuDlg, pv, 420);
    }

    // ----- tab 3: Giảm lag -----
    private void buildLiteTab(JSONObject st) {
        updateStatus(st);
        final Dialog d = menuDlg;
        JSONObject lite = st.optJSONObject("lite");
        LinearLayout col = menuBody;
        if (lite == null) { col.addView(muted("Chưa tải xong trang game.")); return; }

        col.addView(muted("Chọn nhanh"));
        LinearLayout pr = row();
        pr.addView(bigBtn("Tắt", 0xFF1D2530, 0xFFE6EBF2, v -> { liteCall("PSLite.preset('off')"); selectTab(2); }));
        pr.addView(bigBtn("Nhẹ", 0xFF1D2530, 0xFFE6EBF2, v -> { liteCall("PSLite.preset('light')"); selectTab(2); }));
        pr.addView(bigBtn("Mạnh", 0xFF1D2530, 0xFFE6EBF2, v -> { liteCall("PSLite.preset('strong')"); selectTab(2); }));
        pr.addView(bigBtn("Tối đa", 0xFF1D2530, 0xFFE6EBF2, v -> { liteCall("PSLite.preset('max')"); selectTab(2); }));
        col.addView(pr);

        col.addView(bigBtn1(liteAdv ? "▲ Ẩn tuỳ chỉnh chi tiết" : "▼ Tuỳ chỉnh chi tiết", 0xFF1D2530, 0xFFE6EBF2,
                v -> { liteAdv = !liteAdv; selectTab(2); }));
        if (!liteAdv) return;

        col.addView(liteSwitch("Xoá hiệu ứng (fx)", "fx", lite));
        col.addView(liteSwitch("Tắt bóng / blur", "shadow", lite));
        col.addView(liteSwitch("Tắt glow", "glow", lite));
        col.addView(liteSwitch("Tắt số damage / bụi", "part", lite));
        col.addView(liteSwitch("CSS không animation", "css", lite));
        col.addView(liteSwitch("Pixel art (không làm mịn)", "pixel", lite));
        col.addView(liteSwitch("Không vẽ nền map", "bg", lite));

        col.addView(muted("Độ phân giải (dpr)"));
        final double[] dprs = {0, 0.5, 0.75, 1};
        int di = 0;
        for (int i = 0; i < dprs.length; i++) if (Math.abs(dprs[i] - lite.optDouble("dpr", 0)) < 0.001) di = i;
        col.addView(segment(new String[]{"Gốc", "0.5", "0.75", "1"}, di, i -> liteCall("PSLite.set({dpr:" + dprs[i] + "})")));

        col.addView(muted("Bỏ khung hình (vẽ 1 trên N khung)"));
        col.addView(segment(new String[]{"1", "2", "3", "4"}, Math.max(0, Math.min(3, lite.optInt("skip", 1) - 1)),
                i -> liteCall("PSLite.set({skip:" + (i + 1) + "})")));

        col.addView(muted("Ẩn địch"));
        col.addView(segment(new String[]{"Tắt", "Ở xa", "Tất cả"}, Math.max(0, Math.min(2, lite.optInt("hide", 0))),
                i -> liteCall("PSLite.set({hide:" + i + "})")));

        col.addView(muted("Giới hạn FPS (làm chậm game)"));
        final int[] fpss = {0, 45, 30, 20};
        int fi = 0;
        for (int i = 0; i < fpss.length; i++) if (fpss[i] == lite.optInt("fps", 0)) fi = i;
        col.addView(segment(new String[]{"Tắt", "45", "30", "20"}, fi, i -> liteCall("PSLite.set({fps:" + fpss[i] + "})")));
    }

    // ----- tab 4: Tài khoản (tự điền tài khoản + mật khẩu rồi đăng nhập) -----
    private void buildAccountTab() {
        final Dialog d = menuDlg;
        final String site = siteKey(web.getUrl());
        final String[] saved = loadCred(site);
        LinearLayout col = menuBody;

        col.addView(muted("Tài khoản cho trang: " + (site.equals("doof") ? "pokesurvivor.doofcraft.com" : "pokesurvivor.com")
                + " (đổi trang ở tab Cài đặt)"));
        final EditText eu = field("Tên đăng nhập / email", false);
        final EditText ep = field("Mật khẩu", true);
        if (saved != null) {
            eu.setText(saved[0]);
            ep.setHint("•••••••• (đã lưu, để trống = giữ nguyên)");
        }
        col.addView(eu, new LinearLayout.LayoutParams(-1, -2));
        col.addView(ep, new LinearLayout.LayoutParams(-1, -2));
        col.addView(sw("Hiện mật khẩu", false, (b, on) -> {
            int sel = ep.getSelectionStart();
            ep.setInputType(InputType.TYPE_CLASS_TEXT | (on ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            if (sel >= 0) ep.setSelection(sel);
        }));

        col.addView(bigBtn1("💾 Lưu & đăng nhập ngay", 0xFF1F4A33, 0xFF7EE2A8, v -> {
            String u = eu.getText().toString().trim();
            String p = ep.getText().toString();
            if (p.isEmpty() && saved != null) p = saved[1];
            if (u.isEmpty() || p.isEmpty()) { toast("Nhập đủ tài khoản và mật khẩu"); return; }
            if (!saveCred(site, u, p)) { toast("Không lưu được (máy không hỗ trợ khoá bảo mật)"); return; }
            d.dismiss();
            toast("Đang đăng nhập…");
            runLogin(u, p, false);
            ui.postDelayed(() -> web.evaluateJavascript("(window.__TT&&__TT.loginStatus)||'Chưa tải xong trang, thử lại'",
                    r -> toast(unq(r))), 4000);
        }));
        col.addView(sw("Tự đăng nhập khi mở game", prefs.getBoolean("autoLogin", false),
                (b, on) -> prefs.edit().putBoolean("autoLogin", on).apply()));
        col.addView(bigBtn1("Xoá tài khoản đã lưu", 0xFF4D2429, 0xFFFF9A9A, v -> {
            prefs.edit().remove("cred_" + site).apply();
            toast("Đã xoá tài khoản đã lưu");
            selectTab(3);
        }));
        col.addView(muted("Mật khẩu được mã hoá bằng khoá bảo mật của máy và chỉ được điền vào chính trang game. "
                + "Nếu game chỉ có đăng nhập bằng Google thì tính năng này không dùng được."));
    }

    // ----- tab 5: Cài đặt ứng dụng -----
    private void buildAppTab() {
        final Dialog d = menuDlg;
        LinearLayout col = menuBody;

        col.addView(muted("Trang"));
        LinearLayout n1 = row();
        n1.addView(bigBtn("pokesurvivor.com", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); web.loadUrl(HOME_DEFAULT); }));
        n1.addView(bigBtn("doofcraft", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); web.loadUrl(HOME_DOOF); }));
        n1.addView(bigBtn("⟳ Tải lại", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); web.reload(); }));
        col.addView(n1);

        col.addView(section("Ứng dụng"));
        col.addView(sw("Tự xoay ngang", prefs.getBoolean("landscape", true), (b, on) -> {
            prefs.edit().putBoolean("landscape", on).apply();
            applyOrientation();
        }));
        col.addView(sw("Toàn màn hình", prefs.getBoolean("fullscreen", true), (b, on) -> {
            prefs.edit().putBoolean("fullscreen", on).apply();
            applyWindowFlags();
        }));
        col.addView(sw("Giữ màn hình sáng", prefs.getBoolean("keepAwake", true), (b, on) -> {
            prefs.edit().putBoolean("keepAwake", on).apply();
            applyWindowFlags();
        }));
        col.addView(sw("Ẩn bảng điều khiển trong trang", prefs.getBoolean("hidePanel", true), (b, on) -> {
            prefs.edit().putBoolean("hidePanel", on).apply();
            js("window.__TT&&__TT.hide(" + on + ")");
            if (docStartSupported) registerDocStart();
        }));

        LinearLayout n2 = row();
        n2.addView(bigBtn("Xoá dữ liệu trang", 0xFF4D2429, 0xFFFF9A9A, v -> new AlertDialog.Builder(this)
                .setMessage("Xoá cache, dữ liệu và cookie của trang? Bạn sẽ bị đăng xuất.")
                .setPositiveButton("Xoá", (dd, w) -> {
                    d.dismiss();
                    web.clearCache(true);
                    android.webkit.WebStorage.getInstance().deleteAllData();
                    CookieManager.getInstance().removeAllCookies(null);
                    Toast.makeText(this, "Đã xoá dữ liệu & cookie. Đang tải lại…", Toast.LENGTH_SHORT).show();
                    web.reload();
                })
                .setNegativeButton("Huỷ", null).show()));
        n2.addView(bigBtn("Thoát app", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); finishAffinity(); }));
        col.addView(n2);
    }

    private void botCall(String code) {
        js("(function(){if(!window.PSBot)return 'nobot';" + code + ";return 'ok'})()");
    }

    private void liteCall(String code) {
        js("(function(){if(!window.PSLite)return 'nolite';" + code + ";return 'ok'})()");
    }

    private void setRun(String key, String val) {
        js("(function(){try{var k='psbot.dcRun',o=JSON.parse(localStorage.getItem(k)||'{}');o['" + key + "']='" + val
                + "';localStorage.setItem(k,JSON.stringify(o))}catch(e){}})()");
    }

    private int idx(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    // ---------- helpers dựng UI ----------
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFF8FB4FF);
        tv.setTextSize(16);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    // Nút to (52dp) trong hàng ngang, chia đều chiều rộng
    private Button bigBtn(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = btn(t, bgc, fg, l);
        b.setTextSize(14);
        b.setMinimumHeight(dp(52));
        return b;
    }

    // Nút to chiếm cả chiều rộng khi đặt trong cột dọc
    private Button bigBtn1(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = bigBtn(t, bgc, fg, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(2), dp(4), dp(2), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private EditText field(String hint, boolean pass) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6B7684);
        e.setTextColor(Color.WHITE);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setMinHeight(dp(48));
        e.setInputType(InputType.TYPE_CLASS_TEXT | (pass ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS));
        e.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        return e;
    }

    private TextView section(String t) {
        TextView tv = new TextView(this);
        tv.setText(t.toUpperCase());
        tv.setTextColor(0xFF8D99A8);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(10), 0, dp(2));
        return tv;
    }

    private TextView muted(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFFB9C3D0);
        tv.setTextSize(12);
        tv.setPadding(0, dp(3), 0, dp(1));
        return tv;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private Button btn(String t, View.OnClickListener l) {
        return btn(t, 0xFF1D2530, 0xFFE6EBF2, l);
    }

    private Button btn(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(fg);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(dp(44));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bgc);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0xFF3A4553);
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private Switch sw(String t, boolean on, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(t);
        s.setTextColor(0xFFE6EBF2);
        s.setTextSize(13);
        s.setChecked(on);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setMinHeight(dp(48));
        s.setOnCheckedChangeListener(l);
        return s;
    }

    private Switch liteSwitch(String t, final String key, JSONObject lite) {
        return sw(t, lite.optBoolean(key), (b, on) -> liteCall("PSLite.set({" + key + ":" + on + "})"));
    }

    // Hàng nút chọn 1 trong N; nút đang chọn được tô vàng
    private LinearLayout segment(String[] labels, int selected, IntConsumer pick) {
        final LinearLayout l = row();
        final Button[] bs = new Button[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            bs[i] = btn(labels[i], v -> {
                for (int j = 0; j < bs.length; j++) paint(bs[j], j == idx);
                pick.accept(idx);
            });
            paint(bs[i], i == selected);
            l.addView(bs[i]);
        }
        return l;
    }

    private void paint(Button b, boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(sel ? 0xFF3A3016 : 0xFF1D2530);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), sel ? 0xFFFFCC33 : 0xFF3A4553);
        b.setBackground(g);
        b.setTextColor(sel ? 0xFFFFCC33 : 0xFFE6EBF2);
    }
}
